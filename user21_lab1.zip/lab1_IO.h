/*
Header for the Lab 1 IO functions
*/
#ifndef LAB1_H_INCLUDE
#define LAB1_H_INCLUDE

int Lab1_loadinput(int*** A, int*** B, int* size);
int Lab1_saveoutput(int** C, int* size, double Time);

#endif
